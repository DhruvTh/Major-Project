
from multiprocessing import process
from operator import pos
import numpy as np
import matplotlib.pyplot as plt
import cv2
from tf_pose import common
from tf_pose.estimator import TfPoseEstimator
from tf_pose.networks import get_graph_path, model_wh
from datetime import datetime
import time
import pandas as pd
import matplotlib
import pickle
import serial
import serial.tools.list_ports
from matplotlib.animation import FuncAnimation
import json

from flask import Flask, escape, request, render_template, Response, make_response, redirect
import numpy as np
import matplotlib.pyplot as plt
from mpl_toolkits.mplot3d import Axes3D
import cv2

matplotlib.use('agg')


import logging
log = logging.getLogger('werkzeug')
log.setLevel(logging.ERROR)


app = Flask(__name__)



class pose_estimation:
    def __init__(self, processing = 'high'):
        if (processing=='low'):
            self.model='mobilenet_thin'
            self.resize='432x368'
        if (processing=='high'):
            self.model='cmu'
            self.resize='656x368'
            
        
        self.w, self.h = model_wh(self.resize)
        self.e = TfPoseEstimator(get_graph_path(self.model), target_size=(self.w, self.h))
        self.vid = cv2.VideoCapture(0)
        
        self.rangle = 0
        self.langle = 0
        self.cap1 = False
        
    def pose1(self):
        
        while True:
            ret, frame = self.vid.read()
            
            
            humans = self.e.inference(frame, resize_to_default=(self.w > 0 and self.h > 0), upsample_size=4.0)
            human_with_ske = TfPoseEstimator.draw_humans(frame, humans, imgcopy=False)    
            black_background = np.zeros(frame.shape)
            skeleton = TfPoseEstimator.draw_humans(black_background, humans, imgcopy=False)
            
            if(humans==[]):
                humans='No'

            partlist=[]
            stri=str(humans[0])
            for i in range(0,len(stri)):
                parts=[]
                if(stri[i]==':'):
                    if(stri[i+2]=='-'):
                        parts.append(float(stri[i+1:i+2]))
                        parts.append(float(stri[i+4:i+8]))
                        parts.append(float(stri[i+10:i+14]))
                    if(stri[i+3]=='-'):
                        parts.append(float(stri[i+1:i+3]))
                        parts.append(float(stri[i+5:i+9]))
                        parts.append(float(stri[i+11:i+15]))

                    partlist.append(parts)

            partlist=np.array(partlist)
            

            for i in range(0,len(partlist)):
                if(partlist[i][0]==9 and len(partlist)> 9 ):
                    if( partlist[i+1][0]==10 and partlist[i-1][0]==8):
                        l1=partlist[i][1:]-partlist[i+1][1:]
                        l2=partlist[i][1:]-partlist[i-1][1:]
                        arg = sum(l1*l2)/(np.linalg.norm(l1)*np.linalg.norm(l2))
                        self.rangle=round(np.arccos(arg)*180/np.pi, 4)
                        skeleton1 = cv2.putText(skeleton, "Right angle:"+str(self.rangle),(50,50) , cv2.FONT_HERSHEY_SIMPLEX, 0.5, (255, 255, 255), 0, cv2.LINE_AA)


                if(partlist[i][0]==12 and len(partlist) >12):
                    if(partlist[i+1][0]==13 and partlist[i-1][0]==11):
                        l1=partlist[i][1:]-partlist[i+1][1:]
                        l2=partlist[i][1:]-partlist[i-1][1:]
                        arg = sum(l1*l2)/(np.linalg.norm(l1)*np.linalg.norm(l2))
                        self.langle=round(np.arccos(arg)*180/np.pi, 4)
                        skeleton1 = cv2.putText(skeleton, "Left angle:"+str(self.langle), (50,90) , cv2.FONT_HERSHEY_SIMPLEX, 0.5, (255, 255, 255), 0, cv2.LINE_AA)
                
                
            human_with_ske = cv2.copyMakeBorder(human_with_ske, 40, 40, 40, 20, cv2.BORDER_CONSTANT, None, value = 0)
            skeleton = cv2.copyMakeBorder(skeleton, 40, 40, 20, 40, cv2.BORDER_CONSTANT, None, value = 0)
            human_with_ske=cv2.resize(human_with_ske,(600,550))
            skeleton=cv2.resize(skeleton,(600,550))
            img=np.hstack((human_with_ske,skeleton))
            #cv2.imwrite('cap_images/skeleton.jpg', img)
            
            
            now = time.time()
            if(self.cap1==True):
                cv2.imwrite('cap_images_pose/'+str(now)+'.jpg', img)
                self.cap1 = False
                
            ret2, buffer2 = cv2.imencode('.jpg', img)
            frame = buffer2.tobytes()
            
            yield(b'--frame\r\n'
                  b'Content-Type: image/jpeg\r\n\r\n' + frame + b'\r\n')
            

com = [pose_estimation()]
processing = ['low']
capture = ['']


@app.route('/', methods=['GET', 'POST'])
def index():
        
    if request.method == "POST":
        processing[0] = request.values.get('processing')
        capture[0] = request.values.get('capture')
        
    if(capture[0] != '' and capture[0] != None):
        com[0].cap1 = True
        capture[0] = ''

    
    
    if(processing[0] != '' and processing[0] != None):
        com[0] = pose_estimation(processing[0])
        
    return render_template('index.html', processing = processing[0])
            
    
@app.route('/video1')
def video1():
    return Response(com[0].pose1(), mimetype='multipart/x-mixed-replace; boundary=frame')


@app.route('/data')
def data():
    data = [com[0].langle, com[0].rangle]
    response = make_response(json.dumps(data))
    response.content_type = 'application/json'
    return response



if __name__ == '__main__':
    app.debug = True
    app.run()
    
    